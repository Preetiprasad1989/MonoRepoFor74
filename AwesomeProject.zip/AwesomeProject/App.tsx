import React, { useState } from 'react';
import { View, TextInput, Button, Text, Dimensions } from 'react-native';
import { Int32 } from 'react-native/Libraries/Types/CodegenTypes';
 
function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [sum, setSum] = useState<Int32|null>(null);
 
  const handleSum = () => {
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);
    if (!isNaN(number1) && !isNaN(number2)) {
      setSum(number1 + number2);
    } else {
      setSum(null);
    }
  };
 
  return (
    <View style={{backgroundColor:"red", height:Dimensions.get("screen").height,width:Dimensions.get("screen").width}}>
      <TextInput
        style={{top:100}}
        testID="input1"
        placeholder="Enter first number"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
       style={{top:200}}
        testID="input2"
        placeholder="Enter second number"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />
      <Button testID="calculate-button" title="Calculate Sum" onPress={handleSum} />
      {sum !== null && <Text testID="result">{sum.toString()}</Text>}
    </View>
  );
};
 
export default App;