/**
 * @format
 */

import 'react-native';
import App from '../App';
import renderer from 'react-test-renderer';

import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';

// describe('<App />', () => {
//   const tree = renderer.create(<App />).toJSON();
  
//   it('has 2 child', () => {
//     expect(tree.children.length).toBe(2);
//   });

//   it('has Hello string in first child', () => {
//     expect(tree.children[0].children).toStrictEqual(['Hello']);
//   });
// });
describe('Sum of numbers', () => {
  it('calculates the sum of two numbers', () => {
    const { getByTestId } = render(<App />);
    
    // Input values
    fireEvent.changeText(getByTestId('input1'), '5');
    fireEvent.changeText(getByTestId('input2'), '3');
    
    // Click the button
    fireEvent.press(getByTestId('calculate-button'));

    // Check the result
    const result = getByTestId('result');
    expect(result.props.children).toEqual('8');
  });

  it('handles invalid inputs', () => {
    const { getByTestId } = render(<App />);
    
    // Input invalid values
    fireEvent.changeText(getByTestId('input1'), 'five');
    fireEvent.changeText(getByTestId('input2'), 'three');
    
    // Click the button
    fireEvent.press(getByTestId('calculate-button'));

    // Check that result is not displayed
    expect(() => getByTestId('result')).toThrow();
  });
});


